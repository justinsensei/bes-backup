---
name: obsidian-notes
description: Use when managing the Notes/ directory, conceptual mapping, and coordinating Thoughts, Beliefs, Decisions, Projects, References, and Concepts categories.
version: 1.0.0
author: Bes
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [obsidian, notes, folder-conventions]
    related_skills: [obsidian, obsidian-thoughts-beliefs, obsidian-decisions, obsidian-projects, obsidian-references-sources, obsidian-graph-enrichment]
---

# Obsidian Type: Notes Directory Conventions

## Overview
This skill governs the physical structure and coordinate mapping of the `/Notes/` top-level directory in Justin's vault.

---

## Directory & Sub-skills
- **Directory:** `/home/justin.guest/vault/Notes/`
- **Sub-skills (Categories):**
  - **`obsidian-thoughts-beliefs`**: For raw reflections or core principles (`category: "[[Thoughts]]"` or `category: "[[Beliefs]]"`).
  - **`obsidian-decisions`**: For trade-offs, architecture decisions, and reasoning logs (`category: "[[Decisions]]"`).
  - **`Memories`**: For journal-like personal notes, conversations, and good days (`category: "[[Memories]]"`).
  - **`obsidian-projects`**: For ongoing project hubs, travel, or milestones (`category: "[[Projects]]"`).
  - **`obsidian-references-sources`**: For factsheets or conceptual summaries (`category: "[[References]]"` or `category: "[[Concepts]]"`).
  - **`obsidian-people` / `obsidian-organizations`**: For contact notes representing individuals or entities (`category: "[[People]]"` or `category: "[[Organizations]]"`, stored under `/Notes/Contacts/`).
  - **`obsidian-daily-notes`**: For chronological logs and agendas (`category: "[[Daily Notes]]"`, stored under `/Notes/Daily Notes/`).
  - **`obsidian-graph-enrichment`**: Rules and link hierarchy conventions for maintaining a clean note graph.
  - **`obsidian-suggest-links`**: Proactively find surprising linkages among Thoughts and Beliefs.
  - **`obsidian-suggest-new-notes`**: Proactively discover and initialize new notes from log files.
  - **`obsidian-suggest-promotions`**: Proactively promote notes up the hierarchical tiers.

---

## Folder-Level Rules

### Naming Conventions
- All files under `/Notes/` and its subdirectories must use Spaced, Capitalized names.
- **All Categories (Notes, Decisions, Thoughts, Memories, Concepts, References, Beliefs, Projects, People, Organizations):** Must be named `Title ID.md` with the 14-digit ID at the end (e.g. `Spaced Title 20260609120000.md`, `Aly Lalji 20260611074153.md`).

### Rationale for Naming
Note IDs are systematically appended to the end of every note in the `Notes/` directory and its subdirectories (including projects, contacts, and references). This ensures a robust, redundant, and backward-compatible way to automatically repair and resolve broken links, preventing "ghost links" even if files are renamed or shifted across categories.

### Evolution Path (The Scraps-to-Beliefs Pipeline)
Raw capture flows up the hierarchy as it is refined:
- **`[[Scraps]]` (Tier 1):** Raw internal brain dumps in `Inbox/`.
- **`[[Notes]]` (Tier 2):** Compiled, factual supporting notes in `/Notes/ID Title.md`.
- **`[[Thoughts]]` (Tier 2):** Emergent opinions or concepts in `/Notes/ID Title.md`.
- **`[[Beliefs]]` / `[[References]]` (Tier 3):** Canonical, stable patterns in `/Notes/Title.md`.

### Aliases
- Ensure complex, conceptual, or heavily-referenced notes define clean `aliases:` lists in their YAML frontmatter. This allows effortless wikilinking without typing the full exact title every time.
